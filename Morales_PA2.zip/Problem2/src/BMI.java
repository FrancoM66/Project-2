
import java.util.Scanner;
public class BMI {

	public static void main(String[] args) {
	Scanner scan = new Scanner(System.in); 
	
	/*
	 * Ask which formula they want
	 * take input
	 * do the maths
	 * 
	 */
	
	int america;
	int feet;
	int inches;
	double weightInPounds;
	double heightInInches;
	double weightInKilograms;
	double heightInMeters;
	double BMI;
	
	System.out.println("Which formula would you like to use?\n");
	
	System.out.println("Press 1 for:");
	System.out.println("BMI = (703 * weightInPounds) / (heightInInches^2)\n");
	
	System.out.println("Press 2 for:");
	System.out.println("BMI = (weightInKilograms) / (heightInMeters^2)\n");
	
	
	america = scan.nextInt();
	
	if(america == 1) {
		
		System.out.println("You chose:");
		System.out.println("BMI = (703 * weightInPounds) / (heightInInches^2)\n");
		
		System.out.println("Please enter your weight in pounds:");
		
			weightInPounds = scan.nextDouble();
		
		System.out.println("You inputed:" + weightInPounds + " pounds.");
		
		System.out.println("\nPlease enter your height in inches:");
		
			heightInInches = scan.nextDouble();
		
			double WIP = (703.0 * weightInPounds);
			double HII = (heightInInches * heightInInches);
		
		System.out.println("You inputed:\n\n" + heightInInches + " inches.\n");
		
			BMI = WIP / HII;
		
		
		System.out.println("Your Body Mass Index is : " + BMI + "\n\n");
		
		System.out.println("BMI Categories:");
		System.out.println("Underweight = <18.5");
		System.out.println("Normal weight = 18.5�24.9");
		System.out.println("Overweight = 25�29.9");
		System.out.println("Obesity = BMI of 30 or greater");
		
		
	}
	else if (america == 2) {
		
		System.out.println("You chose:");
		System.out.println("BMI = (weightInKilograms) / (heightInMeters^2)\n");
		
		System.out.println("Please enter your weight in kilograms:");
		
			weightInKilograms = scan.nextDouble();
		
		System.out.println("You inputed:" + weightInKilograms + " kilos.");
		
		System.out.println("\nPlease enter your height in meters:");
		
			heightInMeters = scan.nextDouble();
		
		System.out.println("You inputed:\n\n" + heightInMeters + " meters.\n");
		
			double WIK = (weightInKilograms);
			double HIM = (heightInMeters * heightInMeters);
		
			BMI = WIK / HIM;
		
		
		System.out.println("Your Body Mass Index is : " + BMI + "\n\n");
		
		System.out.println("BMI Categories:");
		System.out.println("Underweight = <18.5");
		System.out.println("Normal weight = 18.5�24.9");
		System.out.println("Overweight = 25�29.9");
		System.out.println("Obesity = BMI of 30 or greater");
		
		
	}
	else {
		
		System.out.println("Not a valid choice :(");
		
	}
	
	
	
	
	}
	
}
