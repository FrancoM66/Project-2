import java.util.Scanner;

public class Encryption {

	public static void main(String[] args) {
		
		/*
		 * Take the input (4 digit integer)
		 * Add 7 to the digit and % 10
		 * Swap 1st digit with 3rd
		 * Swap 2nd digit with 4th
		 * Print the digits
		 * 
		 */
		
		Scanner scan = new Scanner(System.in);
		
		int userInput;   
		int remainder; 
		int digit0; 
		int digit1;
		int digit2;
		int digit3;
		
		System.out.println("Please enter a 4 digit number: ");
		
		userInput = scan.nextInt();
		
		if(userInput > 999 && userInput < 10000) {
			digit3 = userInput % 10;       
			remainder = userInput / 10;
		
			digit3 = (digit3 + 7) % 10;
		
		
			digit2 = remainder % 10;
			remainder = remainder / 10;
		
			digit2 = (digit2 + 7) % 10;
		
		
		
			digit1 = remainder % 10;
			remainder = remainder / 10;
		
			digit1 = (digit1 + 7) % 10;
		
		
		
			digit0 = remainder % 10;
			remainder = remainder / 10;
		
			digit0 = (digit0 + 7) % 10;
		

		
		System.out.print("Your encrypted number is:\n" + digit2 + digit3 + digit0 +digit1);
		
		}
		
		else {
			
			System.out.print("Please enter a valid number");
			
		}
		
	}

}

		
	
	


