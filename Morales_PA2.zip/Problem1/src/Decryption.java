import java.util.Scanner;
public class Decryption {
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		int userInput;   
		int remainder; 
		int digit0; 
		int digit1;
		int digit2;
		int digit3;
		
		
		
		System.out.println("Please enter a 4 digit encrypted number: ");
		
		userInput = scan.nextInt();
		
		digit3 = userInput % 10;       
		remainder = userInput / 10;
	
	
	
		digit2 = remainder % 10;
		remainder = remainder / 10;
	
	
		digit1 = remainder % 10;
		remainder = remainder / 10;
	
	
	
		digit0 = remainder % 10;
		remainder = remainder / 10;
		
		if (digit0 >= 8) {
			
			digit0 = digit0 - 7;
		
			
		}
		
		else if (digit0 == 9 ) {
			
			digit0 = digit0 - 7;
		}
		
		else if ((digit0 >= 0) && (digit0 <= 6)) {
			
			digit0 = digit0 + 3;
			
		}
		
		else {
			
			System.out.println("That is not a valid number.");
			
		}
		
		if (digit1 >= 8) {
			
			digit1 = digit1 - 7;
		
			
		}
		
		else if (digit1 == 9 ) {
			
			digit1 = digit1 - 7;
		}
		
		else if ((digit1 >= 0) && (digit1 <= 6)) {
			
			digit1 = digit1 + 3;
			
		}
		
		else {
			
			System.out.println("That is not a valid number.");
			
		}
		
		if (digit2 >= 8) {
			
			digit2 = digit2 - 7;
		
			
		}
		
		else if (digit2 == 9 ) {
			
			digit2 = digit2 - 7;
		}
		
		else if ((digit2 >= 0) && (digit2 <= 6)) {
			
			digit2 = digit2 + 3;
			
		}
		
		else {
			
			System.out.println("That is not a valid number.");
			
		}
		
		if (digit3 >= 8) {
			
			digit3 = digit3 - 7;
		
			
		}
		
		else if (digit3 == 9 ) {
			
			digit3 = digit3 - 7;
		}
		
		else if ((digit3 >= 0) && (digit3 <= 6)) {
			
			digit3 = digit3 + 3;
			
		}
		
		else {
			
			System.out.println("That is not a valid number.");
			
		}

	
		System.out.print("Your decrypted number is:\n" + digit2 + digit3 + digit0 +digit1);
		
		
		
	}
}
