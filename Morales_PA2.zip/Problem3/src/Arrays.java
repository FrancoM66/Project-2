
import java.util.Scanner;

public class Arrays {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        String[] topics = new String[5];
        int[][] responses = new int[5][10];
        //how many people have taken survey (counter)
        int p = 0;
        
        //assigning array topics
        topics[0] = "Politics";
        topics[1] = "Enviornment";
        topics[2] = "School";
        topics[3] = "Family";
        topics[4] = "Friends";
        
        //prompting user
        System.out.println("How many people will be taking the survey?");
        System.out.println("1-10 only please");
        int peeps = scan.nextInt();
        
        //first loop (people)
        for (int i = 0; i < peeps; i++) {
        	
        	//second loop (topics[i])
            for (int w = 0; w < 5; w++) {

                System.out.println(topics[w]);

                System.out.println("What are your opinions on this topic?");

                System.out.println("1 (least important) to 10 (most important).");

                responses[w][i] = scan.nextInt();
            }
            //counter for people
            p++;
           
        }
        //UI / table
        System.out.println("");
        System.out.println("Topic\t\t#1\t#2\t#3\t#4\t#5\t#6\t#7\t#8\t#9\t#10\tMax\tLeast\tTotal\tAverage");
        
        //count checks if everyone has answered
        int count = 0;
        
        for (int i = 0; i < 5; i++) {
            if (responses[i][p-1] > 0 && responses[i][p-1] < 11) {

                count++;

            }
            //once everyone is accounted for finally prints
            if (count == 5) {

                for (int w = 0; w < 5; w++) {

                    System.out.print(topics[w] + ": ");
                    int biggest = 0;
                    int smallest = 10;
                    int total = 0;
                    int average = 0;
        
  
                    for(int s = 0; s < 10; s++){
                        if(responses[w][s] > biggest){
                            biggest = responses[w][s];
                        }
                        if(responses[w][s] < smallest){
                            smallest = responses[w][s];
                        }
                       
                        
                        total += responses[w][s];
                 
                        average = total / peeps;
                        System.out.print("\t" + responses[w][s] + " ");
                    }
                    
                    System.out.print("\t" + biggest + "\t" + smallest + "\t" + total + "\t" + average);
                    System.out.println("");
                }
            }
        }
    }
}
